"""Offline tests for the trips API: Supabase and Groq are faked, so no keys or network are needed.

Run from backend/:  pytest tests/test_trips.py
"""

from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

import lib.groq as groq_module
import routers.trips as trips_router
from lib.auth import get_access_token, get_current_user
from models.auth import AuthUser
from models.trips import DayPlan, Itinerary
from server import app

TRIP_FORM = {
    "destination": "Jaipur",
    "start_date": "2026-12-01",
    "end_date": "2026-12-03",
    "vibe": "Cultural",
    "interests": ["forts", "food"],
    "group_size": 2,
    "budget_per_day": 3000,
    "notes": "vegetarian",
}


def _itinerary(days: int) -> Itinerary:
    return Itinerary(
        summary="Test plan",
        days=[
            DayPlan(day=i, title=f"Day {i}", morning="Fort", afternoon="Market", evening="Show", food="Dal baati", estimated_cost=2500)
            for i in range(1, days + 1)
        ],
    )


class FakeQuery:
    """Tiny in-memory stand-in for supabase's table().select/insert/delete().eq().execute() chain."""

    def __init__(self, store, name):
        self.store, self.name, self.op, self.payload, self.filters = store, name, "select", None, []

    def select(self, *_):
        return self

    def insert(self, row):
        self.op, self.payload = "insert", row
        return self

    def delete(self):
        self.op = "delete"
        return self

    def eq(self, key, value):
        self.filters.append((key, str(value)))
        return self

    def order(self, *_, **__):
        return self

    def limit(self, *_):
        return self

    def execute(self):
        rows = self.store.setdefault(self.name, [])

        def match(row):
            return all(str(row.get(k)) == v for k, v in self.filters)

        if self.op == "insert":
            row = {"id": str(uuid4()), "created_at": "2026-11-01T10:00:00+00:00", **self.payload}
            rows.append(row)
            return SimpleNamespace(data=[row])
        if self.op == "delete":
            gone = [r for r in rows if match(r)]
            self.store[self.name] = [r for r in rows if not match(r)]
            return SimpleNamespace(data=gone)
        return SimpleNamespace(data=[r for r in rows if match(r)])


@pytest.fixture
def api(monkeypatch):
    store: dict = {}
    fake_db = SimpleNamespace(table=lambda name: FakeQuery(store, name))
    monkeypatch.setattr(trips_router, "get_supabase_for_user", lambda token: fake_db)

    async def fake_generate(prompt, expected_days):
        return _itinerary(expected_days)

    monkeypatch.setattr(trips_router, "generate_itinerary", fake_generate)
    app.dependency_overrides[get_current_user] = lambda: AuthUser(id="user-a")
    app.dependency_overrides[get_access_token] = lambda: "token-a"
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


def _login_as(user_id: str):
    app.dependency_overrides[get_current_user] = lambda: AuthUser(id=user_id)


def _save_trip(api) -> dict:
    itinerary = api.post("/api/trips/generate", json=TRIP_FORM).json()
    response = api.post("/api/trips", json={**TRIP_FORM, "itinerary": itinerary})
    assert response.status_code == 201, response.text
    return response.json()


def test_requires_login():
    with TestClient(app) as client:  # no dependency overrides -> no cookie -> 401
        assert client.get("/api/trips").status_code == 401
        assert client.post("/api/trips/generate", json=TRIP_FORM).status_code == 401


def test_generate_returns_one_card_per_day(api):
    response = api.post("/api/trips/generate", json=TRIP_FORM)
    assert response.status_code == 200
    assert [d["day"] for d in response.json()["days"]] == [1, 2, 3]


def test_generate_rejects_trips_longer_than_14_days(api):
    response = api.post("/api/trips/generate", json={**TRIP_FORM, "end_date": "2027-01-30"})
    assert response.status_code == 422


def test_generate_rejects_bad_vibe(api):
    assert api.post("/api/trips/generate", json={**TRIP_FORM, "vibe": "relaxed"}).status_code == 422


def test_save_list_get_delete(api):
    trip = _save_trip(api)
    assert trip["destination"] == "Jaipur"
    assert len(api.get("/api/trips").json()) == 1
    assert api.get(f"/api/trips/{trip['id']}").json()["itinerary"]["days"][0]["morning"] == "Fort"
    assert api.delete(f"/api/trips/{trip['id']}").status_code == 204
    assert api.get("/api/trips").json() == []
    assert api.delete(f"/api/trips/{trip['id']}").status_code == 404


def test_other_user_cannot_see_or_delete_my_trip(api):
    trip = _save_trip(api)
    _login_as("user-b")
    assert api.get("/api/trips").json() == []
    assert api.get(f"/api/trips/{trip['id']}").status_code == 404
    assert api.delete(f"/api/trips/{trip['id']}").status_code == 404
    _login_as("user-a")
    assert api.get(f"/api/trips/{trip['id']}").status_code == 200  # still there for the owner


def test_saved_places(api):
    trip = _save_trip(api)
    base = f"/api/trips/{trip['id']}/places"
    place = api.post(base, json={"place_name": "Amber Fort", "notes": "go early"})
    assert place.status_code == 201
    assert [p["place_name"] for p in api.get(base).json()] == ["Amber Fort"]
    assert api.delete(f"{base}/{place.json()['id']}").status_code == 204
    assert api.get(base).json() == []


def test_cannot_save_place_on_someone_elses_trip(api):
    trip = _save_trip(api)
    _login_as("user-b")
    response = api.post(f"/api/trips/{trip['id']}/places", json={"place_name": "Hawa Mahal"})
    assert response.status_code == 404


def test_bad_trip_id_is_422(api):
    assert api.get("/api/trips/not-a-uuid").status_code == 422


# ---- Groq retry logic (no network: _chat_json is faked) ----


def _good(days: int) -> dict:
    return _itinerary(days).model_dump(mode="json")


@pytest.mark.asyncio
async def test_groq_retries_once_on_bad_output(monkeypatch):
    answers = iter([{"days": []}, _good(2)])  # 1st answer invalid, 2nd fine

    async def fake_chat(prompt):
        return next(answers)

    monkeypatch.setattr(groq_module, "_chat_json", fake_chat)
    result = await groq_module.generate_itinerary("p", expected_days=2)
    assert len(result.days) == 2


@pytest.mark.asyncio
async def test_groq_gives_up_after_two_bad_answers(monkeypatch):
    async def fake_chat(prompt):
        return _good(1)  # asked for 3 days, always returns 1

    monkeypatch.setattr(groq_module, "_chat_json", fake_chat)
    with pytest.raises(ValueError):
        await groq_module.generate_itinerary("p", expected_days=3)


def test_recommendation_accepts_decimal_and_rupee_budgets():
    from models.recommendations import Recommendation

    base = {"destination": "Goa", "summary": "x", "best_for": "y"}
    assert Recommendation(**base, estimated_daily_budget=3500.5).estimated_daily_budget in (3500, 3501)
    assert Recommendation(**base, estimated_daily_budget="₹3,500").estimated_daily_budget == 3500
