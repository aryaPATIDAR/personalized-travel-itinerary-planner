from fastapi import APIRouter, Depends, HTTPException

from lib.auth import get_current_user
from lib.groq import generate_recommendations
from lib.prompts import build_itinerary_prompt
from models.auth import AuthUser
from models.recommendations import RecommendationRequest, RecommendationResponse

router = APIRouter()


@router.post("/recommend", response_model=RecommendationResponse)
async def recommend(
    preferences: RecommendationRequest,
    _user: AuthUser = Depends(get_current_user),
) -> RecommendationResponse:
    try:
        return await generate_recommendations(build_itinerary_prompt(preferences))
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail="Recommendations are temporarily unavailable. Please try again.",
        ) from exc
