import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Response, status

from lib.auth import _value, as_auth_user, get_current_user
from lib.supabase import create_supabase_public_client
from models.auth import AuthResponse, AuthUser, Credentials, SessionResponse

router = APIRouter()
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "false").lower() == "true"


def _set_access_cookie(response: Response, session: Any) -> None:
    access_token = _value(session, "access_token")
    if access_token:
        response.set_cookie(
            "wp_access_token",
            access_token,
            httponly=True,
            secure=COOKIE_SECURE,
            samesite="lax",
            max_age=3600,
            path="/",
        )


@router.post("/auth/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def register(credentials: Credentials, response: Response) -> AuthResponse:
    try:
        result = create_supabase_public_client().auth.sign_up(
            {"email": str(credentials.email), "password": credentials.password}
        )
        user = _value(result, "user")
        session = _value(result, "session")
        if not user:
            raise ValueError("Supabase did not return a user")
        auth_user = as_auth_user(user)
        if session:
            _set_access_cookie(response, session)
            return AuthResponse(user=auth_user, authenticated=True)
        return AuthResponse(
            user=auth_user,
            authenticated=False,
            message="Check your email to confirm your account, then log in.",
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Registration failed. Try another email.") from exc


@router.post("/auth/login", response_model=AuthResponse)
async def login(credentials: Credentials, response: Response) -> AuthResponse:
    try:
        result = create_supabase_public_client().auth.sign_in_with_password(
            {"email": str(credentials.email), "password": credentials.password}
        )
        user = _value(result, "user")
        session = _value(result, "session")
        if not user or not session:
            raise ValueError("Missing authenticated session")
        auth_user = as_auth_user(user)
        _set_access_cookie(response, session)
        return AuthResponse(user=auth_user, authenticated=True)
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid email or password.") from exc


@router.post("/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(response: Response) -> None:
    response.delete_cookie("wp_access_token", path="/")


@router.get("/auth/session", response_model=SessionResponse)
async def session(user: AuthUser = Depends(get_current_user)) -> SessionResponse:
    return SessionResponse(user=user)
