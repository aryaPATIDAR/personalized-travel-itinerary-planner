import logging
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Response, status

from lib.auth import get_access_token, get_current_user
from lib.groq import generate_itinerary
from lib.prompts import build_full_itinerary_prompt
from lib.supabase import get_supabase_for_user
from models.auth import AuthUser
from models.trips import (
    Itinerary,
    ItineraryRequest,
    PlaceCreate,
    PlaceOut,
    TripCreate,
    TripOut,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/trips", tags=["trips"])


def _db_error(action: str) -> HTTPException:
    logger.exception("Database error while trying to %s", action)
    return HTTPException(status_code=502, detail="Database request failed. Please try again.")


def _find_trip(db: Any, trip_id: UUID, user_id: str) -> dict:
    """One trip owned by this user, or 404. RLS also enforces this - belt and braces."""
    try:
        result = (
            db.table("trips").select("*").eq("id", str(trip_id)).eq("user_id", user_id).limit(1).execute()
        )
    except Exception as exc:
        raise _db_error("read trip") from exc
    if not result.data:
        raise HTTPException(status_code=404, detail="Trip not found")
    return result.data[0]


@router.post("/generate", response_model=Itinerary)
async def generate(
    request: ItineraryRequest,
    _user: AuthUser = Depends(get_current_user),
) -> Itinerary:
    """Ask the AI for a day-by-day plan. Nothing is saved - call POST /trips to save it."""
    try:
        return await generate_itinerary(build_full_itinerary_prompt(request), request.num_days)
    except Exception as exc:
        logger.exception("Itinerary generation failed")
        raise HTTPException(
            status_code=502,
            detail="Itinerary is temporarily unavailable. Please try again.",
        ) from exc


@router.post("", response_model=TripOut, status_code=status.HTTP_201_CREATED)
def create_trip(
    body: TripCreate,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> TripOut:
    row = {
        "user_id": user.id,
        "destination": body.destination,
        "start_date": body.start_date.isoformat(),
        "end_date": body.end_date.isoformat(),
        "vibe": body.vibe,
        "interests": body.interests,
        "group_size": body.group_size,
        "budget_per_day": body.budget_per_day,
        "notes": body.notes,
        "itinerary": body.itinerary.model_dump(mode="json"),
    }
    try:
        result = get_supabase_for_user(token).table("trips").insert(row).execute()
    except Exception as exc:
        raise _db_error("save trip") from exc
    if not result.data:
        raise HTTPException(status_code=502, detail="Trip could not be saved.")
    return TripOut.model_validate(result.data[0])


@router.get("", response_model=list[TripOut])
def list_trips(
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> list[TripOut]:
    try:
        result = (
            get_supabase_for_user(token)
            .table("trips")
            .select("*")
            .eq("user_id", user.id)
            .order("created_at", desc=True)
            .execute()
        )
    except Exception as exc:
        raise _db_error("list trips") from exc
    return [TripOut.model_validate(row) for row in result.data or []]


@router.get("/{trip_id}", response_model=TripOut)
def get_trip(
    trip_id: UUID,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> TripOut:
    return TripOut.model_validate(_find_trip(get_supabase_for_user(token), trip_id, user.id))


@router.delete("/{trip_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_trip(
    trip_id: UUID,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> Response:
    try:
        result = (
            get_supabase_for_user(token)
            .table("trips")
            .delete()
            .eq("id", str(trip_id))
            .eq("user_id", user.id)
            .execute()
        )
    except Exception as exc:
        raise _db_error("delete trip") from exc
    if not result.data:
        raise HTTPException(status_code=404, detail="Trip not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---- saved places (belong to a trip) ----


@router.post("/{trip_id}/places", response_model=PlaceOut, status_code=status.HTTP_201_CREATED)
def add_place(
    trip_id: UUID,
    body: PlaceCreate,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> PlaceOut:
    db = get_supabase_for_user(token)
    _find_trip(db, trip_id, user.id)  # also makes sure the trip is really yours
    row = {
        "user_id": user.id,
        "trip_id": str(trip_id),
        "place_name": body.place_name,
        "notes": body.notes,
    }
    try:
        result = db.table("saved_places").insert(row).execute()
    except Exception as exc:
        raise _db_error("save place") from exc
    if not result.data:
        raise HTTPException(status_code=502, detail="Place could not be saved.")
    return PlaceOut.model_validate(result.data[0])


@router.get("/{trip_id}/places", response_model=list[PlaceOut])
def list_places(
    trip_id: UUID,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> list[PlaceOut]:
    db = get_supabase_for_user(token)
    _find_trip(db, trip_id, user.id)
    try:
        result = (
            db.table("saved_places")
            .select("*")
            .eq("trip_id", str(trip_id))
            .eq("user_id", user.id)
            .order("created_at", desc=True)
            .execute()
        )
    except Exception as exc:
        raise _db_error("list places") from exc
    return [PlaceOut.model_validate(row) for row in result.data or []]


@router.delete("/{trip_id}/places/{place_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_place(
    trip_id: UUID,
    place_id: UUID,
    user: AuthUser = Depends(get_current_user),
    token: str = Depends(get_access_token),
) -> Response:
    try:
        result = (
            get_supabase_for_user(token)
            .table("saved_places")
            .delete()
            .eq("id", str(place_id))
            .eq("trip_id", str(trip_id))
            .eq("user_id", user.id)
            .execute()
        )
    except Exception as exc:
        raise _db_error("delete place") from exc
    if not result.data:
        raise HTTPException(status_code=404, detail="Place not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
