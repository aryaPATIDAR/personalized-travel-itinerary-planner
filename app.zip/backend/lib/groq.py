import json
import logging
import os
from typing import Any, Callable, TypeVar

import httpx

from models.recommendations import RecommendationResponse
from models.trips import Itinerary

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
logger = logging.getLogger(__name__)
T = TypeVar("T")


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


async def _chat_json(prompt: str) -> dict[str, Any]:
    payload = {
        "model": os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile"),
        "messages": [
            {
                "role": "system",
                "content": "You return only valid JSON for a travel planning app.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.4,
        "response_format": {"type": "json_object"},
    }
    headers = {
        "Authorization": f"Bearer {_required_env('GROQ_API_KEY')}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(GROQ_URL, headers=headers, json=payload)
        response.raise_for_status()
        result: dict[str, Any] = response.json()

    content = result.get("choices", [{}])[0].get("message", {}).get("content")
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Groq returned an empty response")

    parsed = json.loads(content)
    if not isinstance(parsed, dict):
        raise ValueError("Groq returned JSON that is not an object")
    return parsed


async def _generate(prompt: str, validate: Callable[[dict[str, Any]], T]) -> T:
    """Call Groq and validate. Bad JSON / wrong shape is retried once (LLMs slip sometimes).

    pydantic ValidationError and json.JSONDecodeError are both ValueError subclasses.
    Network and config errors (httpx, RuntimeError) are NOT retried here.
    """
    last_error: Exception | None = None
    for attempt in (1, 2):
        try:
            return validate(await _chat_json(prompt))
        except ValueError as exc:
            last_error = exc
            logger.warning("Groq output rejected (attempt %s/2): %s", attempt, exc)
    raise ValueError("Groq returned invalid output twice") from last_error


async def generate_recommendations(prompt: str) -> RecommendationResponse:
    return await _generate(prompt, RecommendationResponse.model_validate)


async def generate_itinerary(prompt: str, expected_days: int) -> Itinerary:
    def validate(data: dict[str, Any]) -> Itinerary:
        itinerary = Itinerary.model_validate(data)
        if len(itinerary.days) != expected_days:
            raise ValueError(f"Expected {expected_days} days, got {len(itinerary.days)}")
        for number, day in enumerate(itinerary.days, start=1):
            day.day = number
        return itinerary

    return await _generate(prompt, validate)
