"""Supabase clients for server-side database and auth work.

The service-role client is backend-only. Never import this module from the
frontend or return its key from an API response.
"""

import os
from supabase import Client, create_client


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def get_supabase_admin() -> Client:
    return create_client(
        _required_env("SUPABASE_URL"),
        _required_env("SUPABASE_SERVICE_ROLE_KEY"),
    )


def get_supabase_public() -> Client:
    return create_client(
        _required_env("SUPABASE_URL"),
        _required_env("SUPABASE_ANON_KEY"),
    )


def create_supabase_public_client() -> Client:
    """Create an isolated public client for one auth operation."""
    return get_supabase_public()


def get_supabase_for_user(access_token: str) -> Client:
    """Public client that sends the USER's token, so Row Level Security applies.

    Use this for everything a user does (trips, places). Use get_supabase_admin() only when
    you truly need to bypass RLS - it can read every user's data.
    """
    client = get_supabase_public()
    client.postgrest.auth(access_token)
    return client
