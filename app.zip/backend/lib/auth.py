from typing import Any

from fastapi import Cookie, HTTPException, status

from lib.supabase import create_supabase_public_client
from models.auth import AuthUser


def _value(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def as_auth_user(user: Any) -> AuthUser:
    user_id = _value(user, "id")
    if not user_id:
        raise ValueError("Supabase response did not contain a user id")
    return AuthUser(id=str(user_id), email=_value(user, "email"))


def get_current_user(
    access_token: str | None = Cookie(default=None, alias="wp_access_token"),
) -> AuthUser:
    if not access_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    try:
        response = create_supabase_public_client().auth.get_user(access_token)
        user = _value(response, "user")
        if not user:
            raise ValueError("Missing authenticated user")
        return as_auth_user(user)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired. Please log in again.",
        ) from exc


def get_access_token(
    access_token: str | None = Cookie(default=None, alias="wp_access_token"),
) -> str:
    """The raw token, so database calls can run AS the user (this is what makes RLS work)."""
    if not access_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    return access_token
