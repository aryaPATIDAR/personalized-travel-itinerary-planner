import re
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

Vibe = Literal["Relaxed", "Adventure", "Luxury", "Budget", "Cultural", "Foodie"]


class RecommendationRequest(BaseModel):
    destination: str = Field(min_length=2, max_length=100)
    start_date: date
    end_date: date
    vibe: Vibe
    interests: list[str] = Field(min_length=1, max_length=8)
    group_size: int = Field(ge=1, le=20)
    budget_per_day: float = Field(ge=0, le=1_000_000)
    notes: str = Field(default="", max_length=1000)

    @model_validator(mode="after")
    def validate_date_range(self) -> "RecommendationRequest":
        if self.end_date < self.start_date:
            raise ValueError("end_date must be on or after start_date")
        return self


class Recommendation(BaseModel):
    destination: str = Field(min_length=2)
    summary: str = Field(min_length=1)
    best_for: str = Field(min_length=1)
    estimated_daily_budget: int = Field(ge=0)

    @field_validator("estimated_daily_budget", mode="before")
    @classmethod
    def _coerce_budget(cls, value):
        # LLMs sometimes return 3500.5 or "₹3,500" - accept both instead of failing the request.
        if isinstance(value, float):
            return round(value)
        if isinstance(value, str):
            digits = re.sub(r"[^\d.]", "", value)
            return round(float(digits)) if digits else value
        return value


class RecommendationResponse(BaseModel):
    suggestions: list[Recommendation] = Field(min_length=3, max_length=3)
