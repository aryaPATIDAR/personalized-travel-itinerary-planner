import re
from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, Field, field_validator, model_validator

from models.recommendations import RecommendationRequest

MAX_TRIP_DAYS = 14


class DayPlan(BaseModel):
    day: int = Field(ge=1)
    title: str = ""
    morning: str = Field(min_length=1)
    afternoon: str = Field(min_length=1)
    evening: str = Field(min_length=1)
    food: str = ""
    estimated_cost: float = Field(ge=0)

    @field_validator("estimated_cost", mode="before")
    @classmethod
    def _coerce_cost(cls, value):
        if isinstance(value, str):
            digits = re.sub(r"[^\d.]", "", value)
            return float(digits) if digits else value
        return value


class Itinerary(BaseModel):
    summary: str = ""
    days: list[DayPlan] = Field(min_length=1, max_length=MAX_TRIP_DAYS)


class ItineraryRequest(RecommendationRequest):
    """Same fields as the recommend form, plus a cap on trip length (keeps the AI prompt small)."""

    @model_validator(mode="after")
    def validate_trip_length(self) -> "ItineraryRequest":
        if self.num_days > MAX_TRIP_DAYS:
            raise ValueError(f"Trips can be at most {MAX_TRIP_DAYS} days long")
        return self

    @property
    def num_days(self) -> int:
        return (self.end_date - self.start_date).days + 1


class TripCreate(ItineraryRequest):
    itinerary: Itinerary


class TripOut(BaseModel):
    id: UUID
    destination: str
    start_date: date
    end_date: date
    vibe: str
    interests: list[str]
    group_size: int
    budget_per_day: float
    notes: str
    itinerary: Itinerary
    created_at: datetime


class PlaceCreate(BaseModel):
    place_name: str = Field(min_length=1, max_length=200)
    notes: str = Field(default="", max_length=1000)


class PlaceOut(BaseModel):
    id: UUID
    trip_id: UUID
    place_name: str
    notes: str
    created_at: datetime
