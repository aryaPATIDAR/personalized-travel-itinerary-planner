from pydantic import BaseModel, EmailStr, Field


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class AuthUser(BaseModel):
    id: str
    email: EmailStr | None = None


class AuthResponse(BaseModel):
    user: AuthUser
    authenticated: bool
    message: str | None = None


class SessionResponse(BaseModel):
    user: AuthUser
