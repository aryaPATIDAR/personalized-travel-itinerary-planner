import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from routers.health import router as health_router
from routers.auth import router as auth_router
from routers.recommend import router as recommend_router
from routers.trips import router as trips_router


# Create the main app without a prefix
app = FastAPI(title="WanderPlan API", version="0.1.0")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


api_router.include_router(health_router)
api_router.include_router(auth_router)
api_router.include_router(recommend_router)
api_router.include_router(trips_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://10.176.49.230:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Keep this last so every route is registered on api_router before mounting it.
app.include_router(api_router)
