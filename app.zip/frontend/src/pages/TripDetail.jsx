import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Trash2 } from "lucide-react";
import { apiFetch } from "../lib/api.js";
import { ErrorBox, ItineraryView, CopyButton } from "../components/Bits.jsx";

export default function TripDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const [trip, setTrip] = useState(null);
  const [error, setError] = useState(null);

  const load = () => { setError(null); apiFetch(`/trips/${id}`).then(setTrip).catch(setError); };
  useEffect(load, [id]);

  const remove = async () => {
    if (!window.confirm(`Delete your ${trip.destination} trip?`)) return;
    try { await apiFetch(`/trips/${id}`, { method: "DELETE" }); nav("/trips"); } catch (err) { setError(err); }
  };

  if (error?.status === 404) return <p>Trip not found. <Link className="font-medium text-sea underline" to="/trips">Back to My Trips</Link></p>;
  return (
    <div>
      <Link to="/trips" className="text-sm font-medium text-sea underline">Back to My Trips</Link>
      <ErrorBox error={error} onRetry={load} />
      {!trip && !error && <p className="mt-4">Loading...</p>}
      {trip && (
        <>
          <h1 className="mt-2 text-3xl font-bold">{trip.destination}</h1>
          <p className="mt-1 text-ink/75">{trip.start_date} to {trip.end_date} - {trip.vibe} vibe</p>
          <div className="my-5 flex gap-3">
            <CopyButton trip={trip} itinerary={trip.itinerary} />
            <button className="btn btn-ghost" onClick={remove}><Trash2 className="h-4 w-4" /> Delete trip</button>
          </div>
          <ItineraryView itinerary={trip.itinerary} />
        </>
      )}
    </div>
  );
}
