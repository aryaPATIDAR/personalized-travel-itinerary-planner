import { Link } from "react-router-dom";

// Temporary page for routes built in later steps.
export default function ComingSoon({ name }) {
  return (
    <div className="mx-auto max-w-md px-5 py-24 text-center">
      <h1 className="text-2xl font-bold">{name}</h1>
      <p className="mt-2 text-ink/70">This page is built in the next step.</p>
      <Link to="/" className="mt-6 inline-block font-medium text-sea underline">
        Back to home
      </Link>
    </div>
  );
}
