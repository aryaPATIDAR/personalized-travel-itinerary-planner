import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch, VIBES, rupees } from "../lib/api.js";
import { ErrorBox } from "../components/Bits.jsx";

const INTERESTS = ["Beaches", "Food", "History", "Nature", "Nightlife", "Shopping", "Adventure sports", "Temples", "Photography", "Wildlife"];
const today = new Date().toISOString().slice(0, 10);

function days(f) {
  return Math.round((new Date(f.end_date) - new Date(f.start_date)) / 86400000) + 1;
}

function check(step, f) {
  if (step === 1) {
    if (f.destination.trim().length < 2) return "Enter a destination (at least 2 characters).";
    if (!f.start_date || !f.end_date) return "Choose a start and end date.";
    if (f.end_date < f.start_date) return "End date must be on or after the start date.";
    if (days(f) > 14) return "Trips can be at most 14 days.";
  }
  if (step === 2 && f.interests.length < 1) return "Pick at least one interest.";
  if (step === 2 && f.interests.length > 8) return "Pick at most 8 interests.";
  if (step === 3) {
    if (!(f.group_size >= 1 && f.group_size <= 20)) return "Group size must be between 1 and 20.";
    if (!(Number(f.budget_per_day) >= 0) || f.budget_per_day === "") return "Enter a daily budget of 0 or more.";
  }
  return "";
}

export default function CreateTrip() {
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [f, setF] = useState({ destination: "", start_date: "", end_date: "", vibe: "Relaxed", interests: [], group_size: 2, budget_per_day: 3000, notes: "" });
  const [msg, setMsg] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState(null);

  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const payload = () => ({ ...f, destination: f.destination.trim(), group_size: Number(f.group_size), budget_per_day: Number(f.budget_per_day), notes: f.notes.trim() });

  const next = () => { const m = check(step, f); setMsg(m); if (!m) setStep(step + 1); };
  const submit = async (e) => {
    e.preventDefault();
    const m = check(3, f); setMsg(m); if (m) return;
    setError(null); setLoading(true);
    try { setIdeas((await apiFetch("/recommend", { method: "POST", body: payload() })).suggestions); }
    catch (err) { setError(err); }
    setLoading(false);
  };

  if (ideas) {
    return (
      <div>
        <h1 className="text-3xl font-bold">Pick a destination</h1>
        <p className="mt-2 text-ink/75">Choose one and we will build your day-by-day plan.</p>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {ideas.map((s) => (
            <div key={s.destination} className="card flex flex-col">
              <h2 className="text-xl font-bold">{s.destination}</h2>
              <p className="mt-2 flex-1">{s.summary}</p>
              <p className="mt-3 text-sm"><b>Best for:</b> {s.best_for}</p>
              <p className="text-sm"><b>About</b> {rupees(s.estimated_daily_budget)} per day</p>
              <button className="btn btn-primary mt-4" onClick={() => nav("/itinerary", { state: { form: { ...payload(), destination: s.destination } } })}>Plan this trip</button>
            </div>
          ))}
        </div>
        <button className="btn btn-ghost mt-6" onClick={() => setIdeas(null)}>Change my answers</button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card mx-auto max-w-xl">
      <p className="text-sm font-medium text-sea-dark">Step {step} of 3</p>
      {step === 1 && (
        <div className="mt-3 space-y-4">
          <h1 className="text-2xl font-bold">Where and when?</h1>
          <div><label className="label" htmlFor="d">Destination</label><input id="d" className="input" maxLength={100} value={f.destination} onChange={(e) => set("destination", e.target.value)} /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="s">Start date</label><input id="s" type="date" min={today} className="input" value={f.start_date} onChange={(e) => set("start_date", e.target.value)} /></div>
            <div><label className="label" htmlFor="e">End date</label><input id="e" type="date" min={f.start_date || today} className="input" value={f.end_date} onChange={(e) => set("end_date", e.target.value)} /></div>
          </div>
        </div>
      )}
      {step === 2 && (
        <div className="mt-3 space-y-5">
          <h1 className="text-2xl font-bold">What is your vibe?</h1>
          <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Vibe">
            {VIBES.map((v) => (
              <button type="button" key={v} role="radio" aria-checked={f.vibe === v} onClick={() => set("vibe", v)}
                className={`btn ${f.vibe === v ? "btn-dark" : "btn-ghost"}`}>{v}</button>
            ))}
          </div>
          <div>
            <p className="label">Interests (pick 1 to 8)</p>
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map((i) => {
                const on = f.interests.includes(i);
                return <button type="button" key={i} aria-pressed={on} className={`btn ${on ? "btn-dark" : "btn-ghost"}`}
                  onClick={() => set("interests", on ? f.interests.filter((x) => x !== i) : [...f.interests, i])}>{i}</button>;
              })}
            </div>
          </div>
        </div>
      )}
      {step === 3 && (
        <div className="mt-3 space-y-4">
          <h1 className="text-2xl font-bold">Group and budget</h1>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="g">Group size</label><input id="g" type="number" min={1} max={20} className="input" value={f.group_size} onChange={(e) => set("group_size", e.target.value)} /></div>
            <div><label className="label" htmlFor="b">Daily budget per person (INR)</label><input id="b" type="number" min={0} className="input" value={f.budget_per_day} onChange={(e) => set("budget_per_day", e.target.value)} /></div>
          </div>
          <div><label className="label" htmlFor="n">Extra notes (optional)</label><textarea id="n" rows={3} maxLength={1000} className="input" value={f.notes} onChange={(e) => set("notes", e.target.value)} /></div>
        </div>
      )}
      {msg && <p role="alert" className="mt-4 text-red-700">{msg}</p>}
      <ErrorBox error={error} />
      {loading && <p role="status" className="mt-4">Finding destinations. This can take up to 30 seconds...</p>}
      <div className="mt-6 flex justify-between">
        <button type="button" className="btn btn-ghost" disabled={step === 1 || loading} onClick={() => { setMsg(""); setStep(step - 1); }}>Back</button>
        {step < 3
          ? <button type="button" className="btn btn-primary" onClick={next}>Next</button>
          : <button className="btn btn-primary" disabled={loading}>{loading ? "Please wait..." : "Get destination ideas"}</button>}
      </div>
    </form>
  );
}
