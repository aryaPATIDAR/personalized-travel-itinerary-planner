import { Link } from "react-router-dom";
import { SlidersHorizontal, Sparkles, Shuffle, BookmarkCheck, ClipboardCopy } from "lucide-react";
import Navbar from "../components/Navbar.jsx";
import { VIBES } from "../lib/api.js";

const FEATURES = [
  {
    icon: SlidersHorizontal,
    title: "Tell us how you travel",
    text: "Pick your dates, vibe, interests, group size and daily budget in INR.",
  },
  {
    icon: Sparkles,
    title: "AI-written itinerary",
    text: "Get three destination ideas, then a day-by-day plan with morning, afternoon, evening, food and cost.",
  },
  {
    icon: Shuffle,
    title: "Change the vibe",
    text: "Not feeling it? Regenerate the same trip with a different vibe.",
  },
  {
    icon: BookmarkCheck,
    title: "Save your trips",
    text: "Keep your plans in My Trips. Open them again or delete them anytime.",
  },
  {
    icon: ClipboardCopy,
    title: "Take it with you",
    text: "Copy the full itinerary as text and share it anywhere.",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen">
      <Navbar />

      <main>
        <section className="bg-mist">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:py-24">
            <h1 className="max-w-2xl text-4xl font-extrabold leading-tight sm:text-6xl">
              Plan a trip that fits your vibe, not a template.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-ink/80">
              Share your dates, budget and interests. Get destination ideas and a day-wise itinerary in
              minutes.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/register"
                className="rounded-lg bg-marigold px-6 py-3 font-bold text-ink hover:brightness-95"
              >
                Start planning
              </Link>
              <Link
                to="/login"
                className="rounded-lg border border-ink/20 bg-white px-6 py-3 font-medium hover:bg-white/60"
              >
                I already have an account
              </Link>
            </div>

            <ul className="mt-12 flex flex-wrap gap-2" aria-label="Available vibes">
              {VIBES.map((v) => (
                <li
                  key={v}
                  className="rounded-full border border-sea/30 bg-white px-4 py-1.5 text-sm font-medium text-sea-dark"
                >
                  {v}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-16">
          <h2 className="text-3xl font-bold">What you can do</h2>
          <div className="mt-8 grid gap-x-10 gap-y-8 sm:grid-cols-2">
            {FEATURES.map(({ icon: Icon, title, text }) => (
              <div key={title} className="flex gap-4">
                <Icon className="mt-1 h-6 w-6 shrink-0 text-sea" aria-hidden="true" />
                <div>
                  <h3 className="text-lg font-bold">{title}</h3>
                  <p className="mt-1 text-ink/75">{text}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-ink/10 py-6 text-center text-sm text-ink/60">
        Trip Planner
      </footer>
    </div>
  );
}
