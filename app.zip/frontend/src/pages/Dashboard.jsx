import { Link } from "react-router-dom";
import { PlusCircle, Luggage } from "lucide-react";
import { useAuth } from "../lib/auth.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  return (
    <div>
      <h1 className="text-3xl font-bold">Welcome{user?.email ? `, ${user.email}` : ""}</h1>
      <p className="mt-2 text-ink/75">What do you want to do?</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Link to="/trips/new" className="card hover:border-sea">
          <PlusCircle className="h-7 w-7 text-sea" aria-hidden="true" />
          <h2 className="mt-3 text-xl font-bold">Plan a new trip</h2>
          <p className="mt-1 text-ink/75">Answer a few questions and get destination ideas.</p>
        </Link>
        <Link to="/trips" className="card hover:border-sea">
          <Luggage className="h-7 w-7 text-sea" aria-hidden="true" />
          <h2 className="mt-3 text-xl font-bold">My Trips</h2>
          <p className="mt-1 text-ink/75">Open or delete the trips you saved.</p>
        </Link>
      </div>
    </div>
  );
}
