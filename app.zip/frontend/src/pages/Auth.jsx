import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth.jsx";
import { ErrorBox } from "../components/Bits.jsx";

export default function Auth({ mode }) {
  const isLogin = mode === "login";
  const { user, login, register } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setError(null); setInfo(""); setBusy(true);
    try {
      const r = await (isLogin ? login : register)({ email, password });
      if (r.authenticated) nav("/dashboard");
      else setInfo(r.message || "Account created. Please log in.");
    } catch (err) { setError(err); }
    setBusy(false);
  };

  return (
    <div className="min-h-screen bg-mist px-5 py-16">
      <div className="card mx-auto max-w-md">
        <h1 className="text-2xl font-bold">{isLogin ? "Log in" : "Create your account"}</h1>
        <form onSubmit={submit} className="mt-5 space-y-4">
          <div><label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><label className="label" htmlFor="pw">Password (8+ characters)</label>
            <input id="pw" type="password" required minLength={8} maxLength={128} className="input" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <ErrorBox error={error} />
          {info && <p role="status" className="rounded-lg bg-mist p-3">{info}</p>}
          <button className="btn btn-primary w-full" disabled={busy}>{busy ? "Please wait..." : isLogin ? "Log in" : "Create account"}</button>
        </form>
        <p className="mt-4 text-sm">
          {isLogin ? "New here? " : "Already registered? "}
          <Link className="font-medium text-sea underline" to={isLogin ? "/register" : "/login"}>{isLogin ? "Create an account" : "Log in"}</Link>
        </p>
      </div>
    </div>
  );
}
