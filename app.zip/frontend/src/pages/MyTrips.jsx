import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Trash2 } from "lucide-react";
import { apiFetch } from "../lib/api.js";
import { ErrorBox } from "../components/Bits.jsx";

export default function MyTrips() {
  const [trips, setTrips] = useState(null);
  const [error, setError] = useState(null);

  const load = () => { setError(null); apiFetch("/trips").then(setTrips).catch(setError); };
  useEffect(load, []);

  const remove = async (t) => {
    if (!window.confirm(`Delete your ${t.destination} trip?`)) return;
    try { await apiFetch(`/trips/${t.id}`, { method: "DELETE" }); setTrips(trips.filter((x) => x.id !== t.id)); }
    catch (err) { setError(err); }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold">My Trips</h1>
      <ErrorBox error={error} onRetry={load} />
      {!trips && !error && <p className="mt-4">Loading...</p>}
      {trips && trips.length === 0 && (
        <p className="mt-4">You have no saved trips yet. <Link className="font-medium text-sea underline" to="/trips/new">Plan your first trip</Link></p>
      )}
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        {trips?.map((t) => (
          <div key={t.id} className="card">
            <h2 className="text-xl font-bold">{t.destination}</h2>
            <p className="text-ink/75">{t.start_date} to {t.end_date}</p>
            <p className="text-sm">{t.vibe} - {t.itinerary.days.length} days - {t.group_size} {t.group_size === 1 ? "person" : "people"}</p>
            <div className="mt-4 flex gap-2">
              <Link to={`/trips/${t.id}`} className="btn btn-dark">Open</Link>
              <button className="btn btn-ghost" onClick={() => remove(t)}><Trash2 className="h-4 w-4" /> Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
