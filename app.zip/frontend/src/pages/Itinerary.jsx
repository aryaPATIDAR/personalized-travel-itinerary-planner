import { useEffect, useRef, useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { Shuffle, Save } from "lucide-react";
import { apiFetch, VIBES } from "../lib/api.js";
import { ErrorBox, ItineraryView, CopyButton } from "../components/Bits.jsx";

export default function Itinerary() {
  const form = useLocation().state?.form;
  const nav = useNavigate();
  const [vibe, setVibe] = useState(form?.vibe);
  const [pick, setPick] = useState(VIBES.find((v) => v !== form?.vibe));
  const [it, setIt] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const started = useRef(false);
  const [retry, setRetry] = useState(null);

  const generate = async (v) => {
    setLoading(true); setError(null);
    try {
      setIt(await apiFetch("/trips/generate", { method: "POST", body: { ...form, vibe: v } }));
      setVibe(v);
    } catch (err) { setError(err); setRetry(() => () => generate(v)); }
    setLoading(false);
  };
  useEffect(() => { if (form && !started.current) { started.current = true; generate(form.vibe); } }, []); // eslint-disable-line

  if (!form) return <Navigate to="/trips/new" replace />;

  const save = async () => {
    setSaving(true); setError(null);
    try {
      const t = await apiFetch("/trips", { method: "POST", body: { ...form, vibe, itinerary: it } });
      nav(`/trips/${t.id}`);
    } catch (err) { setError(err); setRetry(() => save); }
    setSaving(false);
  };

  const trip = { ...form, vibe };
  return (
    <div>
      <h1 className="text-3xl font-bold">{form.destination}</h1>
      <p className="mt-1 text-ink/75">{form.start_date} to {form.end_date} - {vibe} vibe</p>
      {loading && <p role="status" className="my-6">Building your itinerary. This can take up to 30 seconds...</p>}
      <ErrorBox error={error} onRetry={retry} />
      {it && !loading && (
        <>
          <div className="my-5 flex flex-wrap items-end gap-3">
            <div>
              <label className="label" htmlFor="v">Try a different vibe</label>
              <select id="v" className="input" value={pick} onChange={(e) => setPick(e.target.value)}>
                {VIBES.filter((v) => v !== vibe).map((v) => <option key={v}>{v}</option>)}
              </select>
            </div>
            <button className="btn btn-ghost" disabled={saving} onClick={() => generate(pick)}><Shuffle className="h-4 w-4" /> Regenerate with a different vibe</button>
            <CopyButton trip={trip} itinerary={it} />
            <button className="btn btn-primary" disabled={saving} onClick={save}><Save className="h-4 w-4" /> {saving ? "Saving..." : "Save trip"}</button>
          </div>
          <ItineraryView itinerary={it} />
        </>
      )}
    </div>
  );
}
