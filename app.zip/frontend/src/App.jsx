import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./lib/auth.jsx";
import Shell from "./components/Shell.jsx";
import Landing from "./pages/Landing.jsx";
import Auth from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import CreateTrip from "./pages/CreateTrip.jsx";
import Itinerary from "./pages/Itinerary.jsx";
import MyTrips from "./pages/MyTrips.jsx";
import TripDetail from "./pages/TripDetail.jsx";
import ComingSoon from "./pages/ComingSoon.jsx";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/register" element={<Auth mode="register" />} />
        <Route element={<Shell />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/trips/new" element={<CreateTrip />} />
          <Route path="/itinerary" element={<Itinerary />} />
          <Route path="/trips" element={<MyTrips />} />
          <Route path="/trips/:id" element={<TripDetail />} />
        </Route>
        <Route path="*" element={<ComingSoon name="Page not found" />} />
      </Routes>
    </AuthProvider>
  );
}
