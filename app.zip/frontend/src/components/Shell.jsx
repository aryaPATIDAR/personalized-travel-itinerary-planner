import { Link, Navigate, Outlet, useNavigate } from "react-router-dom";
import { Compass, LogOut } from "lucide-react";
import { useAuth } from "../lib/auth.jsx";

export default function Shell() {
  const { user, loading, logout } = useAuth();
  const nav = useNavigate();
  if (loading) return <p className="p-10 text-center">Loading...</p>;
  if (!user) return <Navigate to="/login" replace />;
  return (
    <div className="min-h-screen bg-mist">
      <header className="border-b border-ink/10 bg-white">
        <nav className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-3">
          <Link to="/dashboard" className="flex items-center gap-2 font-display text-lg font-bold">
            <Compass className="h-6 w-6 text-sea" aria-hidden="true" /> Trip Planner
          </Link>
          <div className="flex items-center gap-1 text-sm">
            <Link to="/trips/new" className="rounded-lg px-3 py-2 hover:bg-mist">New trip</Link>
            <Link to="/trips" className="rounded-lg px-3 py-2 hover:bg-mist">My Trips</Link>
            <button className="btn btn-ghost" onClick={async () => { await logout(); nav("/"); }}>
              <LogOut className="h-4 w-4" aria-hidden="true" /> Log out
            </button>
          </div>
        </nav>
      </header>
      <main className="mx-auto max-w-5xl px-5 py-8"><Outlet /></main>
    </div>
  );
}
