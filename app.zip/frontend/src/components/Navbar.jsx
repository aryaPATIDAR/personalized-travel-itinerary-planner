import { Link } from "react-router-dom";
import { Compass } from "lucide-react";

export default function Navbar() {
  return (
    <header className="border-b border-ink/10 bg-white">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
          <Compass className="h-6 w-6 text-sea" aria-hidden="true" />
          Trip Planner
        </Link>
        <div className="flex items-center gap-2">
          <Link to="/login" className="rounded-lg px-4 py-2 text-sm font-medium hover:bg-mist">
            Log in
          </Link>
          <Link
            to="/register"
            className="rounded-lg bg-ink px-4 py-2 text-sm font-medium text-white hover:bg-sea-dark"
          >
            Create account
          </Link>
        </div>
      </nav>
    </header>
  );
}
