import { useState } from "react";
import { Sunrise, Sun, Moon, Utensils, Check, Copy } from "lucide-react";
import { rupees, itineraryToText } from "../lib/api.js";

export function ErrorBox({ error, onRetry }) {
  if (!error) return null;
  return (
    <div role="alert" className="my-4 rounded-lg border border-red-300 bg-red-50 p-4 text-red-800">
      <p>{error.status === 502 ? "AI or database is temporarily unavailable, please try again." : error.message}</p>
      {onRetry && <button className="btn btn-dark mt-3" onClick={onRetry}>Retry</button>}
    </div>
  );
}

export function CopyButton({ trip, itinerary }) {
  const [done, setDone] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(itineraryToText(trip, itinerary));
    setDone(true);
    setTimeout(() => setDone(false), 2000);
  };
  return (
    <button className="btn btn-ghost" onClick={copy}>
      {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} {done ? "Copied" : "Copy as text"}
    </button>
  );
}

const Row = ({ icon: Icon, label, text }) => (
  <div className="flex gap-3">
    <Icon className="mt-1 h-5 w-5 shrink-0 text-sea" aria-hidden="true" />
    <p><span className="font-bold">{label}: </span>{text}</p>
  </div>
);

export function ItineraryView({ itinerary }) {
  const total = itinerary.days.reduce((a, d) => a + Number(d.estimated_cost || 0), 0);
  return (
    <div>
      {itinerary.summary && <p className="mb-5 text-lg text-ink/80">{itinerary.summary}</p>}
      <div className="grid gap-4">
        {itinerary.days.map((d) => (
          <article key={d.day} className="card space-y-3">
            <h3 className="text-xl font-bold">Day {d.day}{d.title ? `: ${d.title}` : ""}</h3>
            <Row icon={Sunrise} label="Morning" text={d.morning} />
            <Row icon={Sun} label="Afternoon" text={d.afternoon} />
            <Row icon={Moon} label="Evening" text={d.evening} />
            {d.food && <Row icon={Utensils} label="Food" text={d.food} />}
            <p className="font-bold text-sea-dark">Estimated cost: {rupees(d.estimated_cost)}</p>
          </article>
        ))}
      </div>
      <p className="mt-4 text-right font-bold">Total estimated cost: {rupees(total)}</p>
    </div>
  );
}
