# Frontend (React + Vite + Tailwind)
1. Backend must run on http://localhost:8000 with CORS_ORIGINS=http://localhost:5173
2. `cp .env.example .env`  (VITE_API_URL=http://localhost:8000/api)
3. `npm install` then `npm run dev` -> http://localhost:5173
Use `localhost` everywhere (not 127.0.0.1) so the login cookie works.
