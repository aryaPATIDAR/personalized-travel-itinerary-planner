# Personalized Travel Itinerary Planner

React (Vite + Tailwind) + FastAPI + Supabase + Groq.

## Folders
- `backend/`  FastAPI API (port 8000, all routes under /api)
- `frontend/` React app (port 5173)
- `database/schema.sql`  Supabase tables + Row Level Security

## Setup
1. **Database:** Supabase -> SQL Editor -> paste `database/schema.sql` -> Run.
2. **Backend:**
   ```
   cd backend
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   cp ../.env.example .env         # fill in the real values
   uvicorn server:app --reload --port 8000
   ```
   Open http://localhost:8000/docs
3. **Frontend:**
   ```
   cd frontend
   cp .env.example .env
   npm install
   npm run dev
   ```
   Open http://localhost:5173  (use `localhost`, not 127.0.0.1)

## Tests (backend, offline)
`cd backend && pip install -r requirements-dev.txt && pytest`

## How I tested (checklist)
- [ ] Register and log in
- [ ] Create trip -> 3 destination cards
- [ ] Pick one -> itinerary shows day cards
- [ ] Regenerate with a different vibe
- [ ] Save trip -> appears in My Trips -> open it
- [ ] Delete a trip
- [ ] Log in as user B: user A's trips are NOT visible

## Notes
- Login uses an HttpOnly cookie (`wp_access_token`, 1 hour, no refresh).
- Never commit `.env`. The service role key stays in the backend only.
