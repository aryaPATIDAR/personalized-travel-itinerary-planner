-- Personalized Travel Itinerary Planner
-- Paste this file into the Supabase SQL Editor and run it once.

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  destination text not null,
  start_date date not null,
  end_date date not null,
  vibe text not null,
  interests text[] not null default '{}',
  group_size integer not null default 1,
  budget_per_day numeric not null default 0,
  notes text not null default '',
  itinerary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default timezone('utc', now()),
  constraint trips_dates_valid check (end_date >= start_date),
  constraint trips_group_size_valid check (group_size > 0),
  constraint trips_budget_valid check (budget_per_day >= 0)
);

create table if not exists public.saved_places (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  trip_id uuid not null references public.trips(id) on delete cascade,
  place_name text not null,
  notes text not null default '',
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists trips_user_id_created_at_idx
  on public.trips (user_id, created_at desc);

create index if not exists saved_places_user_id_created_at_idx
  on public.saved_places (user_id, created_at desc);

alter table public.trips enable row level security;
alter table public.saved_places enable row level security;

drop policy if exists "Users can view their own trips" on public.trips;
create policy "Users can view their own trips"
  on public.trips for select
  using (auth.uid() = user_id);

drop policy if exists "Users can create their own trips" on public.trips;
create policy "Users can create their own trips"
  on public.trips for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own trips" on public.trips;
create policy "Users can update their own trips"
  on public.trips for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own trips" on public.trips;
create policy "Users can delete their own trips"
  on public.trips for delete
  using (auth.uid() = user_id);

drop policy if exists "Users can view their own saved places" on public.saved_places;
create policy "Users can view their own saved places"
  on public.saved_places for select
  using (auth.uid() = user_id);

drop policy if exists "Users can create their own saved places" on public.saved_places;
create policy "Users can create their own saved places"
  on public.saved_places for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own saved places" on public.saved_places;
create policy "Users can update their own saved places"
  on public.saved_places for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own saved places" on public.saved_places;
create policy "Users can delete their own saved places"
  on public.saved_places for delete
  using (auth.uid() = user_id);
